CREATE TABLE public.nf_notas (
  key TEXT PRIMARY KEY,
  data_emissao DATE NOT NULL,
  nota TEXT NOT NULL,
  uf TEXT NOT NULL,
  fornecedor TEXT NOT NULL,
  modalidade TEXT NOT NULL DEFAULT 'Não definido',
  valor NUMERIC(14,2) NOT NULL DEFAULT 0,
  dias INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  deleted BOOLEAN NOT NULL DEFAULT false,
  absent BOOLEAN NOT NULL DEFAULT false,
  first_imported_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.nf_notas TO authenticated;
GRANT ALL ON public.nf_notas TO service_role;
ALTER TABLE public.nf_notas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuarios logados leem notas" ON public.nf_notas FOR SELECT TO authenticated USING (true);
CREATE POLICY "Usuarios logados inserem notas" ON public.nf_notas FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Usuarios logados atualizam notas" ON public.nf_notas FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Usuarios logados excluem notas" ON public.nf_notas FOR DELETE TO authenticated USING (true);

CREATE TABLE public.nf_ops (
  key TEXT PRIMARY KEY,
  transportadora TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT '',
  observacoes TEXT NOT NULL DEFAULT '',
  previsao DATE,
  history JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.nf_ops TO authenticated;
GRANT ALL ON public.nf_ops TO service_role;
ALTER TABLE public.nf_ops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuarios logados leem ops" ON public.nf_ops FOR SELECT TO authenticated USING (true);
CREATE POLICY "Usuarios logados inserem ops" ON public.nf_ops FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Usuarios logados atualizam ops" ON public.nf_ops FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Usuarios logados excluem ops" ON public.nf_ops FOR DELETE TO authenticated USING (true);

CREATE TABLE public.nf_audit (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  at TIMESTAMPTZ NOT NULL DEFAULT now(),
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  keys JSONB
);
GRANT SELECT, INSERT ON public.nf_audit TO authenticated;
GRANT ALL ON public.nf_audit TO service_role;
ALTER TABLE public.nf_audit ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuarios logados leem auditoria" ON public.nf_audit FOR SELECT TO authenticated USING (true);
CREATE POLICY "Usuarios logados registram auditoria" ON public.nf_audit FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE public.nf_status_options (
  value TEXT PRIMARY KEY
);
GRANT SELECT, INSERT, DELETE ON public.nf_status_options TO authenticated;
GRANT ALL ON public.nf_status_options TO service_role;
ALTER TABLE public.nf_status_options ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuarios logados leem status" ON public.nf_status_options FOR SELECT TO authenticated USING (true);
CREATE POLICY "Usuarios logados inserem status" ON public.nf_status_options FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Usuarios logados excluem status" ON public.nf_status_options FOR DELETE TO authenticated USING (true);

INSERT INTO public.nf_status_options (value) VALUES
  ('Extravio'),
  ('Recusa'),
  ('Entregue aguardando liberação fiscal'),
  ('Aguardando canhoto'),
  ('Aguardando agendamento');

ALTER PUBLICATION supabase_realtime ADD TABLE public.nf_notas;
ALTER PUBLICATION supabase_realtime ADD TABLE public.nf_ops;
ALTER PUBLICATION supabase_realtime ADD TABLE public.nf_audit;
ALTER PUBLICATION supabase_realtime ADD TABLE public.nf_status_options;