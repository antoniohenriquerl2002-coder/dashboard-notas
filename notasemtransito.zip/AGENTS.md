<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Invoice (NF) rules live in src/lib/nf.ts as pure functions (reconcile, softDelete, setOp, classify) with tests in src/lib/nf.test.ts; UI only calls them, so import/identity logic stays testable.
- Data persists in Lovable Cloud tables nf_notas / nf_ops / nf_audit / nf_status_options (authenticated-only RLS, Realtime enabled); src/lib/nf-db.ts maps DbState ↔ rows and syncs diffs, keeping imported fields (`notas`) separate from manual fields (`ops`) keyed by Nº Nota|UF|Fornecedor; why: dashboard is shared online with real-time edits across logged-in guests.
