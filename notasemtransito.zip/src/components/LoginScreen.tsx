import { useState } from "react";
import { toast } from "sonner";
import { Lock, LogIn } from "lucide-react";
import logoAsset from "@/assets/rede-ancora.jpeg.asset.json";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export function LoginScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) {
      toast.error("Não foi possível entrar. Confira e-mail e senha.");
      return;
    }
    toast.success("Bem-vindo ao painel!");
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="panel w-full max-w-md p-8">
        <div className="mb-6 flex flex-col items-center text-center">
          <img src={logoAsset.url} alt="Rede Ancora" className="mb-4 h-20 w-20 rounded-2xl object-cover shadow-lg" />
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Rede Ancora · Controle Operacional</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Painel de Notas em Trânsito</h1>
          <p className="mt-2 text-sm text-muted-foreground">Acesso restrito. Entre com o e-mail e a senha recebidos.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">E-mail</span>
            <input
              type="email"
              required
              autoComplete="email"
              className="field"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Senha</span>
            <input
              type="password"
              required
              autoComplete="current-password"
              className="field"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <Button type="submit" size="lg" className="w-full rounded-xl" disabled={loading}>
            {loading ? <Lock className="animate-pulse" /> : <LogIn />}
            {loading ? "Entrando…" : "Entrar"}
          </Button>
        </form>
      </div>
    </div>
  );
}
