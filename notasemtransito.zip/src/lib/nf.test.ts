import { describe, expect, it } from "vitest";
import { clearImported, classify, emptyState, mapHeaders, reconcile, setOp, softDelete } from "./nf";

const row = (nota: number, valor = 100, dias = 10) => ({ "DATA EMISSÃO": "24/08/2026", "NUMERO NOTA": nota, "UF FILIAL": "AL", FORNECEDOR: "INDISA", MODALIDADE: "Normal", VALOR: valor, "DIAS NF": dias, EXTRA: "x" });

describe("classify", () => {
  it("até 7 dias = dentro do prazo", () => expect(classify(7)).toBe("ok"));
  it("8 a 15 = pendente", () => { expect(classify(8)).toBe("pending"); expect(classify(15)).toBe("pending"); });
  it("16 a 29 = atenção", () => { expect(classify(16)).toBe("warn"); expect(classify(29)).toBe("warn"); });
  it("30+ = crítico", () => expect(classify(30)).toBe("crit"));
});

describe("mapHeaders", () => {
  it("ignora colunas UF e Statuspre; usa UF FILIAL", () => {
    const map = mapHeaders(["NUMERO NOTA", "UF", "UF FILIAL", "Statuspre", "FORNECEDOR", "MODALIDADE", "VALOR", "DIAS NF"]);
    expect(map["uf"]).toBe("UF FILIAL");
    expect(Object.values(map)).not.toContain("Statuspre");
  });
});

describe("reconcile", () => {
  it("inclui novas e não duplica em reimportação", () => {
    const a = reconcile(emptyState(), [row(1), row(2)]).state;
    const b = reconcile(a, [row(1), row(2)]);
    expect(Object.keys(b.state.notas)).toHaveLength(2);
    expect(b.summary.inalterados).toBe(2);
  });
  it("preserva transportadora/status ao atualizar valores", () => {
    let s = reconcile(emptyState(), [row(1)]).state;
    const key = Object.keys(s.notas)[0]!;
    s = setOp(s, key, "transportadora", "Braspress");
    const r = reconcile(s, [row(1, 999)]);
    expect(r.summary.atualizados).toBe(1);
    expect(r.state.ops[key]!.transportadora).toBe("Braspress");
    expect(r.state.notas[key]!.valor).toBe(999);
  });
  it("arquiva ausentes e recupera dados manuais ao reimportar", () => {
    let s = reconcile(emptyState(), [row(1), row(2)]).state;
    const key = Object.keys(s.notas).find((k) => k.startsWith("2|"))!;
    s = setOp(s, key, "status", "Recusa");
    s = reconcile(s, [row(1)]).state;
    expect(s.notas[key]!.active).toBe(false);
    const back = reconcile(s, [row(1), row(2)]);
    expect(back.state.notas[key]!.active).toBe(true);
    expect(back.state.ops[key]!.status).toBe("Recusa");
  });
  it("rejeita duplicadas divergentes como ambíguas", () => {
    const r = reconcile(emptyState(), [row(1, 100), row(1, 200)]);
    expect(Object.keys(r.state.notas)).toHaveLength(0);
    expect(r.summary.rejeitados).toBe(2);
  });
  it("aceita valor em formato brasileiro", () => {
    const r = reconcile(emptyState(), [{ ...row(5), VALOR: "R$ 1.234,56" }]);
    expect(Object.values(r.state.notas)[0]!.valor).toBe(1234.56);
  });
  it("falha sem colunas obrigatórias", () => {
    expect(() => reconcile(emptyState(), [{ A: 1 }])).toThrow();
  });
});

describe("softDelete", () => {
  it("remove da listagem ativa mas mantém dados manuais", () => {
    let s = reconcile(emptyState(), [row(1)]).state;
    const key = Object.keys(s.notas)[0]!;
    s = setOp(s, key, "transportadora", "TNT");
    s = softDelete(s, [key]);
    expect(s.notas[key]!.active).toBe(false);
    expect(s.ops[key]!.transportadora).toBe("TNT");
    expect(s.audit[0]!.action).toBe("Exclusão lógica");
  });
});

describe("modalidade e limpar dados", () => {
  it("modalidade vazia vira Não definido", () => {
    const r = reconcile(emptyState(), [{ ...row(7), MODALIDADE: "" }]);
    expect(Object.values(r.state.notas)[0]!.modalidade).toBe("Não definido");
  });
  it("limpar dados preserva observações e previsão ao reimportar", () => {
    let s = reconcile(emptyState(), [row(1)]).state;
    const key = Object.keys(s.notas)[0]!;
    s = setOp(s, key, "observacoes", "Ligar cliente");
    s = setOp(s, key, "previsao", "2026-11-01");
    s = clearImported(s);
    expect(Object.keys(s.notas)).toHaveLength(0);
    s = reconcile(s, [row(1)]).state;
    expect(s.ops[key]!.observacoes).toBe("Ligar cliente");
    expect(s.ops[key]!.previsao).toBe("2026-11-01");
  });
});
