// Core rules for "Notas Fiscais em Trânsito": parsing, identity key, reconciliation, classification.

export type NotaImportada = {
  key: string;
  dataEmissao: string; // yyyy-mm-dd
  nota: string;
  uf: string;
  fornecedor: string;
  modalidade: string;
  valor: number;
  dias: number;
  active: boolean;
  deleted: boolean; // exclusão lógica pelo usuário
  absent: boolean; // ausente na última importação
  firstImportedAt: string;
  updatedAt: string;
};

export type OpField = "transportadora" | "status" | "observacoes" | "previsao";
export type OpsHistory = { at: string; field: OpField; from: string; to: string };
export type Operacional = { transportadora: string; status: string; observacoes?: string; previsao?: string; history: OpsHistory[] };

export type AuditEntry = { at: string; action: string; detail: string; keys?: string[] };

export type DbState = {
  notas: Record<string, NotaImportada>;
  ops: Record<string, Operacional>;
  statusOptions: string[];
  audit: AuditEntry[];
};

export const DEFAULT_STATUS = [
  "Extravio",
  "Recusa",
  "Entregue aguardando liberação fiscal",
  "Aguardando canhoto",
  "Aguardando agendamento",
];

export const emptyState = (): DbState => ({ notas: {}, ops: {}, statusOptions: [...DEFAULT_STATUS], audit: [] });

export type Classe = "ok" | "pending" | "warn" | "crit";
export const CLASSE_LABEL: Record<Classe, string> = {
  ok: "Dentro do prazo",
  pending: "Pendente",
  warn: "Atenção",
  crit: "Crítico",
};
export function classify(dias: number): Classe {
  if (dias <= 7) return "ok";
  if (dias <= 15) return "pending";
  if (dias <= 29) return "warn";
  return "crit";
}

const norm = (s: string) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");

const FIELD_ALIASES: Record<string, string[]> = {
  dataEmissao: ["DATAEMISSAO", "DTEMISSAO", "EMISSAO", "DATADEEMISSAO"],
  nota: ["NUMERONOTA", "NNOTA", "NOTA", "NUMERONF", "NF", "NNF", "NOTAFISCAL", "NUMERODANOTA"],
  // Somente "UF FILIAL": colunas "UF" e "Statuspre" da base são ignoradas na importação.
  uf: ["UFFILIAL"],
  fornecedor: ["FORNECEDOR"],
  modalidade: ["MODALIDADE"],
  valor: ["VALOR", "VALORRS", "VALORR", "VALORNF"],
  dias: ["DIASNF", "DIAS"],
};

export function mapHeaders(headers: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [field, aliases] of Object.entries(FIELD_ALIASES)) {
    const h = headers.find((x) => aliases.includes(norm(x)));
    if (h !== undefined) out[field] = h;
  }
  return out;
}

const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export function parseDate(v: unknown): string | null {
  if (v === null || v === undefined || v === "") return null;
  if (v instanceof Date) return isNaN(v.getTime()) ? null : ymd(v);
  if (typeof v === "number") {
    const d = new Date(Math.round((v - 25569) * 86400 * 1000));
    return isNaN(d.getTime()) ? null : `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/) as string[] | null;
  if (m) {
    const y = m[3]!.length === 2 ? 2000 + +m[3]! : +m[3]!;
    return `${y}-${pad(+m[2]!)}-${pad(+m[1]!)}`;
  }
  m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/) as string[] | null;
  if (m) return `${m[1]}-${pad(+m[2]!)}-${pad(+m[3]!)}`;
  return null;
}

export function parseNumber(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  if (typeof v === "number") return isFinite(v) ? v : null;
  let s = String(v).replace(/R\$|\s/g, "");
  if (!s) return null;
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  const n = Number(s);
  return isFinite(n) ? n : null;
}

export const normNota = (v: unknown) => String(v ?? "").trim().replace(/\.0+$/, "").replace(/^0+(?=\d)/, "");
export const normText = (v: unknown) => String(v ?? "").trim().replace(/\s+/g, " ").toUpperCase();
export function normModalidade(v: unknown): string {
  const t = String(v ?? "").trim();
  if (!t) return "Não definido";
  const n = norm(t);
  if (n === "NORMAL") return "Normal";
  if (n === "CROSSDOCKING") return "Crossdocking";
  if (n === "NAODEFINIDO") return "Não definido";
  return t;
}
export const makeKey = (nota: string, uf: string, fornecedor: string) => `${nota}|${uf}|${norm(fornecedor)}`;

export type ImportSummary = {
  lidos: number;
  incluidos: number;
  atualizados: number;
  inalterados: number;
  reativados: number;
  ignorados: number;
  rejeitados: number;
  ausentes: number;
  erros: string[];
};

type Parsed = Omit<NotaImportada, "active" | "deleted" | "absent" | "firstImportedAt" | "updatedAt">;

const sameData = (a: Parsed, b: NotaImportada) =>
  a.dataEmissao === b.dataEmissao && a.modalidade === b.modalidade && a.valor === b.valor && a.dias === b.dias && a.fornecedor === b.fornecedor;

/** Pure reconciliation: returns a new state; never mutates the input (all-or-nothing). */
export function reconcile(
  prev: DbState,
  rows: Record<string, unknown>[],
  now = new Date().toISOString(),
): { state: DbState; summary: ImportSummary } {
  const summary: ImportSummary = { lidos: rows.length, incluidos: 0, atualizados: 0, inalterados: 0, reativados: 0, ignorados: 0, rejeitados: 0, ausentes: 0, erros: [] };
  if (!rows.length) throw new Error("A planilha não contém registros.");
  const map = mapHeaders(Object.keys(rows[0]!)) as { [K in "dataEmissao" | "nota" | "uf" | "fornecedor" | "modalidade" | "valor" | "dias"]: string };
  const missing = Object.keys(FIELD_ALIASES).filter((f) => !(map as Record<string, string>)[f]);
  if (missing.length) throw new Error(`Colunas obrigatórias não encontradas: ${missing.join(", ")}`);

  const parsed = new Map<string, Parsed>();
  const ambiguous = new Set<string>();
  rows.forEach((r, i) => {
    const line = i + 2;
    const nota = normNota(r[map.nota]);
    const uf = normText(r[map.uf]);
    const fornecedor = normText(r[map.fornecedor]);
    const allEmpty = Object.values(map).every((h) => r[h] === null || r[h] === undefined || String(r[h]).trim() === "");
    if (allEmpty) { summary.ignorados++; return; }
    const dataEmissao = parseDate(r[map.dataEmissao]);
    const valor = parseNumber(r[map.valor]);
    const dias = parseNumber(r[map.dias]);
    const problems: string[] = [];
    if (!nota) problems.push("Nº Nota vazio");
    if (!uf) problems.push("UF vazia");
    if (!fornecedor) problems.push("Fornecedor vazio");
    if (!dataEmissao) problems.push("Data inválida");
    if (valor === null) problems.push("Valor inválido");
    if (dias === null) problems.push("Dias NF inválido");
    if (problems.length) { summary.rejeitados++; summary.erros.push(`Linha ${line}: ${problems.join(", ")}`); return; }
    const key = makeKey(nota, uf, fornecedor);
    const rec: Parsed = { key, nota, uf, fornecedor, dataEmissao: dataEmissao!, modalidade: normModalidade(r[map.modalidade]), valor: Math.round(valor! * 100) / 100, dias: Math.round(dias!) };
    const ex = parsed.get(key);
    if (ex) {
      if (ex.dataEmissao === rec.dataEmissao && ex.valor === rec.valor && ex.dias === rec.dias && ex.modalidade === rec.modalidade) { summary.ignorados++; return; }
      ambiguous.add(key);
      summary.erros.push(`Linha ${line}: nota ${nota}/${uf}/${fornecedor} duplicada com dados divergentes (ambígua)`);
      return;
    }
    parsed.set(key, rec);
  });
  for (const k of ambiguous) { parsed.delete(k); summary.rejeitados += 2; }

  const notas: Record<string, NotaImportada> = {};
  for (const [k, v] of Object.entries(prev.notas)) notas[k] = { ...v };
  for (const [k, rec] of parsed) {
    const old = notas[k];
    if (!old) {
      notas[k] = { ...rec, active: true, deleted: false, absent: false, firstImportedAt: now, updatedAt: now };
      summary.incluidos++;
    } else {
      const wasInactive = !old.active;
      const changed = !sameData(rec, old);
      notas[k] = { ...old, ...rec, active: true, deleted: false, absent: false, updatedAt: changed ? now : old.updatedAt };
      if (wasInactive) summary.reativados++;
      else if (changed) summary.atualizados++;
      else summary.inalterados++;
    }
  }
  for (const [k, n] of Object.entries(notas)) {
    if (!parsed.has(k) && !ambiguous.has(k) && n.active) {
      notas[k] = { ...n, active: false, absent: true };
      summary.ausentes++;
    }
  }
  const audit: AuditEntry[] = [
    { at: now, action: "Importação", detail: `${summary.incluidos} incluídas, ${summary.atualizados} atualizadas, ${summary.inalterados} inalteradas, ${summary.reativados} reativadas, ${summary.ausentes} arquivadas por ausência, ${summary.rejeitados} rejeitadas` },
    ...prev.audit,
  ].slice(0, 500);
  return { state: { ...prev, notas, audit }, summary };
}

export function softDelete(prev: DbState, keys: string[], now = new Date().toISOString()): DbState {
  const notas = { ...prev.notas };
  const affected = keys.filter((k) => notas[k]?.active);
  for (const k of affected) notas[k] = { ...notas[k]!, active: false, deleted: true, updatedAt: now };
  const labels = affected.map((k) => notas[k]!.nota).join(", ");
  return { ...prev, notas, audit: [{ at: now, action: "Exclusão lógica", detail: `${affected.length} nota(s): ${labels}`, keys: affected }, ...prev.audit].slice(0, 500) };
}

export function restore(prev: DbState, keys: string[], now = new Date().toISOString()): DbState {
  const notas = { ...prev.notas };
  for (const k of keys) if (notas[k]) notas[k] = { ...notas[k]!, active: true, deleted: false, absent: false };
  return { ...prev, notas, audit: [{ at: now, action: "Restauração", detail: `${keys.length} nota(s) restaurada(s)`, keys }, ...prev.audit].slice(0, 500) };
}

/** Clears the active imported list; manual data (ops) and audit are preserved for re-import. */
export function clearImported(prev: DbState, now = new Date().toISOString()): DbState {
  const n = Object.keys(prev.notas).length;
  return { ...prev, notas: {}, audit: [{ at: now, action: "Limpar dados", detail: `${n} nota(s) removida(s) da relação; dados manuais preservados` }, ...prev.audit].slice(0, 500) };
}

export function setOp(prev: DbState, key: string, field: OpField, value: string, now = new Date().toISOString()): DbState {
  const cur = prev.ops[key] ?? { transportadora: "", status: "", history: [] };
  if ((cur[field] ?? "") === value) return prev;
  const next: Operacional = { ...cur, [field]: value, history: [{ at: now, field, from: cur[field] ?? "", to: value }, ...cur.history].slice(0, 50) };
  return { ...prev, ops: { ...prev.ops, [key]: next } };
}

const STORAGE_KEY = "nf-transito-db-v1";
export function loadState(): DbState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...emptyState(), ...JSON.parse(raw) } : null;
  } catch {
    return null;
  }
}
export function saveState(s: DbState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
}
