// Camada de persistência na nuvem (Lovable Cloud) para o painel de Notas em Trânsito.
// O estado local (DbState) continua sendo calculado pelas funções puras de nf.ts;
// aqui apenas convertemos de/para as tabelas e sincronizamos as diferenças.

import { supabase } from "@/integrations/supabase/client";
import type { AuditEntry, DbState, NotaImportada, Operacional, OpsHistory } from "@/lib/nf";

type NotaRow = {
  key: string; data_emissao: string; nota: string; uf: string; fornecedor: string;
  modalidade: string; valor: number; dias: number; active: boolean; deleted: boolean;
  absent: boolean; first_imported_at: string; updated_at: string;
};
type OpsRow = {
  key: string; transportadora: string; status: string; observacoes: string;
  previsao: string | null; history: OpsHistory[]; updated_at: string;
};

const notaFromRow = (r: NotaRow): NotaImportada => ({
  key: r.key, dataEmissao: r.data_emissao, nota: r.nota, uf: r.uf, fornecedor: r.fornecedor,
  modalidade: r.modalidade, valor: Number(r.valor), dias: r.dias, active: r.active,
  deleted: r.deleted, absent: r.absent, firstImportedAt: r.first_imported_at, updatedAt: r.updated_at,
});
const notaToRow = (n: NotaImportada): NotaRow => ({
  key: n.key, data_emissao: n.dataEmissao, nota: n.nota, uf: n.uf, fornecedor: n.fornecedor,
  modalidade: n.modalidade, valor: n.valor, dias: n.dias, active: n.active, deleted: n.deleted,
  absent: n.absent, first_imported_at: n.firstImportedAt, updated_at: n.updatedAt,
});
const opsFromRow = (r: OpsRow): Operacional => ({
  transportadora: r.transportadora, status: r.status, observacoes: r.observacoes,
  ...(r.previsao ? { previsao: r.previsao } : {}), history: r.history ?? [],
});
const opsToRow = (key: string, o: Operacional): OpsRow => ({
  key, transportadora: o.transportadora, status: o.status, observacoes: o.observacoes ?? "",
  previsao: o.previsao || null, history: o.history ?? [], updated_at: new Date().toISOString(),
});

const PAGE = 1000;

type Table = "nf_notas" | "nf_ops" | "nf_audit" | "nf_status_options";

async function fetchAll<T>(table: Table, orderBy?: string): Promise<T[]> {
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    let q = supabase.from(table).select("*").range(from, from + PAGE - 1);
    if (orderBy) q = q.order(orderBy, { ascending: false });
    const { data, error } = await q;
    if (error) throw new Error(error.message);
    out.push(...(data as unknown as T[]));
    if (!data || data.length < PAGE) break;
  }
  return out;
}

/** Carrega todo o estado a partir das tabelas na nuvem. */
export async function loadRemoteState(): Promise<DbState> {
  const [notaRows, opsRows, auditRows, statusRows] = await Promise.all([
    fetchAll<NotaRow>("nf_notas"),
    fetchAll<OpsRow>("nf_ops"),
    fetchAll<{ at: string; action: string; detail: string; keys: string[] | null }>("nf_audit", "at"),
    fetchAll<{ value: string }>("nf_status_options"),
  ]);
  const notas: Record<string, NotaImportada> = {};
  for (const r of notaRows) notas[r.key] = notaFromRow(r);
  const ops: Record<string, Operacional> = {};
  for (const r of opsRows) ops[r.key] = opsFromRow(r);
  const audit: AuditEntry[] = auditRows.slice(0, 500).map((r) => ({ at: r.at, action: r.action, detail: r.detail, ...(r.keys?.length ? { keys: r.keys } : {}) }));
  const statusOptions = statusRows.map((r) => r.value);
  return {
    notas, ops, audit,
    statusOptions: statusOptions.length ? statusOptions : [],
  };
}

const CHUNK = 500;
async function upsertNotas(rows: NotaRow[]) {
  for (let i = 0; i < rows.length; i += CHUNK) {
    const { error } = await supabase.from("nf_notas").upsert(rows.slice(i, i + CHUNK));
    if (error) throw new Error(error.message);
  }
}
async function upsertOps(rows: OpsRow[]) {
  for (let i = 0; i < rows.length; i += CHUNK) {
    const { error } = await supabase.from("nf_ops").upsert(rows.slice(i, i + CHUNK));
    if (error) throw new Error(error.message);
  }
}

/** Grava na nuvem a diferença entre o estado anterior e o novo estado. */
export async function persistDiff(prev: DbState, next: DbState): Promise<void> {
  // Notas: upsert das alteradas/novas; remoção das que sumiram (limpar dados)
  const changedNotas: NotaRow[] = [];
  for (const [k, n] of Object.entries(next.notas)) {
    const p = prev.notas[k];
    if (!p || JSON.stringify(p) !== JSON.stringify(n)) changedNotas.push(notaToRow(n));
  }
  const removedNotas = Object.keys(prev.notas).filter((k) => !(k in next.notas));
  if (changedNotas.length) await upsertNotas(changedNotas);
  for (let i = 0; i < removedNotas.length; i += CHUNK) {
    const { error } = await supabase.from("nf_notas").delete().in("key", removedNotas.slice(i, i + CHUNK));
    if (error) throw new Error(error.message);
  }

  // Ops: upsert das alteradas/novas
  const changedOps: OpsRow[] = [];
  for (const [k, o] of Object.entries(next.ops)) {
    const p = prev.ops[k];
    if (!p || JSON.stringify(p) !== JSON.stringify(o)) changedOps.push(opsToRow(k, o));
  }
  if (changedOps.length) await upsertOps(changedOps);

  // Opções de status
  const addedStatus = next.statusOptions.filter((s) => !prev.statusOptions.includes(s));
  const removedStatus = prev.statusOptions.filter((s) => !next.statusOptions.includes(s));
  if (addedStatus.length) {
    const { error } = await supabase.from("nf_status_options").upsert(addedStatus.map((value) => ({ value })));
    if (error) throw new Error(error.message);
  }
  if (removedStatus.length) {
    const { error } = await supabase.from("nf_status_options").delete().in("value", removedStatus);
    if (error) throw new Error(error.message);
  }

  // Auditoria: entradas novas (o estado novo empilha as mais recentes no início)
  const prevAts = new Set(prev.audit.map((a) => `${a.at}|${a.action}|${a.detail}`));
  const newEntries = next.audit.filter((a) => !prevAts.has(`${a.at}|${a.action}|${a.detail}`));
  if (newEntries.length) {
    const { error } = await supabase.from("nf_audit").insert(
      newEntries.map((a) => ({ at: a.at, action: a.action, detail: a.detail, keys: a.keys ?? null })),
    );
    if (error) throw new Error(error.message);
  }
}

/** Assina mudanças em tempo real; chama `onChange` (com debounce) quando algo muda. */
export function subscribeChanges(onChange: () => void): () => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const ping = () => {
    clearTimeout(timer);
    timer = setTimeout(onChange, 400);
  };
  const channel = supabase
    .channel("nf-transito")
    .on("postgres_changes", { event: "*", schema: "public", table: "nf_notas" }, ping)
    .on("postgres_changes", { event: "*", schema: "public", table: "nf_ops" }, ping)
    .on("postgres_changes", { event: "*", schema: "public", table: "nf_audit" }, ping)
    .on("postgres_changes", { event: "*", schema: "public", table: "nf_status_options" }, ping)
    .subscribe();
  return () => {
    clearTimeout(timer);
    supabase.removeChannel(channel);
  };
}
