import { createFileRoute } from "@tanstack/react-router";
import logoAsset from "@/assets/rede-ancora.jpeg.asset.json";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import {
  AlertTriangle, ArrowDown, ArrowUp, ArrowUpDown, Archive, Download, FileText, Building2, Factory, Eraser, Lightbulb, LogOut, RotateCcw, Trash2, Upload, X, Plus, Truck, Wallet, Clock, Flame,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  CLASSE_LABEL, clearImported, classify, DEFAULT_STATUS, emptyState, normModalidade, reconcile, restore, setOp, softDelete,
  type Classe, type DbState, type ImportSummary, type NotaImportada,
} from "@/lib/nf";
import { loadRemoteState, persistDiff, subscribeChanges } from "@/lib/nf-db";
import { LoginScreen } from "@/components/LoginScreen";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Notas em Trânsito — Painel de Controle Fiscal" },
      { name: "description", content: "Dashboard de controle de notas fiscais em trânsito: KPIs, filtros, prazos, status e exportação para Excel." },
      { property: "og:title", content: "Notas em Trânsito — Painel de Controle Fiscal" },
      { property: "og:description", content: "Acompanhe notas fiscais em trânsito, priorize pendências e preserve o histórico operacional." },
    ],
  }),
  component: Dashboard,
});

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const brlShort = (n: number) => (n >= 1e6 ? `R$ ${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `R$ ${(n / 1e3).toFixed(0)}k` : brl(n));
const fmtDate = (s: string) => s.split("-").reverse().join("/");
const CLASSE_COLOR: Record<Classe, string> = { ok: "var(--ok)", pending: "var(--pending)", warn: "var(--warn)", crit: "var(--crit)" };
const CLASSE_BADGE: Record<Classe, string> = {
  ok: "bg-ok/15 text-ok border-ok/30",
  pending: "bg-pending/15 text-pending border-pending/30",
  warn: "bg-warn/15 text-warn border-warn/30",
  crit: "bg-crit/15 text-crit border-crit/30",
};
const CHARTS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const MOD_COLOR: Record<string, string> = { Cross: "var(--chart-2)", Normal: "var(--chart-1)", "Não definido": "var(--chart-3)" };

type Filters = {
  de: string; ate: string; nota: string; uf: string; fornecedor: string; modalidade: string;
  classe: string; status: string;
};
const NO_FILTERS: Filters = { de: "", ate: "", nota: "", uf: "", fornecedor: "", modalidade: "", classe: "", status: "" };
type SortKey = "dataEmissao" | "valor" | "dias" | "nota" | "fornecedor" | "uf";
type Row = NotaImportada & { transportadora: string; status: string; observacoes: string; previsao: string; classe: Classe };

function Dashboard() {
  const [db, setDb] = useState<DbState | null>(null);
  const [filters, setFilters] = useState<Filters>(NO_FILTERS);
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "dias", dir: "desc" });
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(0);
  const [confirmDel, setConfirmDel] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [newStatus, setNewStatus] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const [session, setSession] = useState<boolean | null>(null);

  // Autenticação: convidados entram com e-mail e senha.
  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => { if (mounted) setSession(!!data.user); });
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN") setSession(true);
      if (event === "SIGNED_OUT") { setSession(false); setDb(null); }
    });
    return () => { mounted = false; sub.subscription.unsubscribe(); };
  }, []);

  // Carrega o estado da nuvem (semeando a base embutida no primeiro acesso)
  // e assina mudanças em tempo real feitas por outros usuários.
  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    const reload = async () => {
      try {
        const s = await loadRemoteState();
        if (cancelled) return;
        if (!Object.keys(s.notas).length && !s.audit.length) {
          const rows = await fetch("/data/notas.json").then((r) => r.json());
          const base: DbState = { ...emptyState(), statusOptions: s.statusOptions.length ? s.statusOptions : [...DEFAULT_STATUS] };
          const { state } = reconcile(base, rows);
          await persistDiff(base, state);
          if (!cancelled) setDb(state);
          return;
        }
        // Se há gravações locais pendentes, adia para não sobrescrever o que acabou de ser editado.
        if (pendingRef.current > 0) { staleRef.current = true; return; }
        setDb(s);
      } catch (e) {
        if (!cancelled) toast.error(`Falha ao carregar dados: ${(e as Error).message}`);
      }
    };
    reloadRef.current = () => { void reload(); };
    void reload();
    const unsub = subscribeChanges(() => { void reload(); });
    return () => { cancelled = true; unsub(); reloadRef.current = null; };
  }, [session]);

  const pendingRef = useRef(0);
  const staleRef = useRef(false);
  const reloadRef = useRef<null | (() => void)>(null);
  const commit = (next: DbState) => {
    const prev = db;
    if (!prev) return false;
    setDb(next);
    pendingRef.current++;
    persistDiff(prev, next)
      .catch((e) => {
        toast.error(`Falha ao salvar na nuvem: ${(e as Error).message}`);
        staleRef.current = true;
      })
      .finally(() => {
        pendingRef.current--;
        if (pendingRef.current === 0 && staleRef.current) {
          staleRef.current = false;
          reloadRef.current?.();
        }
      });
    return true;
  };


  const active: Row[] = useMemo(() => {
    if (!db) return [];
    return Object.values(db.notas).filter((n) => n.active).map((n) => ({
      ...n, modalidade: normModalidade(n.modalidade), transportadora: db.ops[n.key]?.transportadora ?? "", status: db.ops[n.key]?.status ?? "",
      observacoes: db.ops[n.key]?.observacoes ?? "", previsao: db.ops[n.key]?.previsao ?? "", classe: classify(n.dias),
    }));
  }, [db]);

  const options = useMemo(() => {
    const u = (f: (r: Row) => string) => [...new Set(active.map(f).filter(Boolean))].sort();
    return { uf: u((r) => r.uf), fornecedor: u((r) => r.fornecedor), modalidade: u((r) => r.modalidade) };
  }, [active]);

  const filtered = useMemo(() => {
    const f = filters;
    const rows = active.filter((r) =>
      (!f.de || r.dataEmissao >= f.de) && (!f.ate || r.dataEmissao <= f.ate) &&
      (!f.nota || r.nota.includes(f.nota.trim())) && (!f.uf || r.uf === f.uf) &&
      (!f.fornecedor || r.fornecedor === f.fornecedor) && (!f.modalidade || r.modalidade === f.modalidade) &&
      (!f.classe || r.classe === f.classe) && (!f.status || (f.status === "__none" ? !r.status : r.status === f.status)),
    );
    const m = sort.dir === "asc" ? 1 : -1;
    return rows.sort((a, b) => {
      const x = a[sort.key], y = b[sort.key];
      if (sort.key === "nota") return (Number(x) - Number(y)) * m;
      return (x < y ? -1 : x > y ? 1 : 0) * m;
    });
  }, [active, filters, sort]);

  useEffect(() => setPage(0), [filters, sort]);

  const filteredTotal = useMemo(() => filtered.reduce((s, r) => s + r.valor, 0), [filtered]);
  const [cdSel, setCdSel] = useState("");
  const cdOptions = useMemo(() => [...new Set(active.map((r) => r.uf))].sort(), [active]);
  const base = useMemo(() => (cdSel ? active.filter((r) => r.uf === cdSel) : active), [active, cdSel]);
  const kpi = useMemo(() => {
    const filtered = base;
    const total = filtered.reduce((s, r) => s + r.valor, 0);
    const crit = filtered.filter((r) => r.classe === "crit");
    return {
      count: filtered.length, total, avgDias: filtered.length ? filtered.reduce((s, r) => s + r.dias, 0) / filtered.length : 0,
      critCount: crit.length, critValor: crit.reduce((s, r) => s + r.valor, 0),
      semStatus: filtered.filter((r) => !r.status).length,
    };
  }, [base]);

  const charts = useMemo(() => {
    const filtered = base;
    const group = (f: (r: Row) => string) => {
      const m = new Map<string, { name: string; valor: number; qtd: number }>();
      for (const r of filtered) { const k = f(r) || "—"; const g = m.get(k) ?? { name: k, valor: 0, qtd: 0 }; g.valor += r.valor; g.qtd++; m.set(k, g); }
      return [...m.values()];
    };
    const modBucket = (m: string) => (m === "Crossdocking" ? "Cross" : m === "Normal" ? "Normal" : m);
    const modOrder = ["Cross", "Normal", "Não definido"];
    const modMap = new Map<string, { name: string; valor: number; qtd: number }>();
    for (const r of filtered) { const k = modBucket(r.modalidade); const g = modMap.get(k) ?? { name: k, valor: 0, qtd: 0 }; g.valor += r.valor; g.qtd++; modMap.set(k, g); }
    const byModGroup = [...modMap.values()].sort((a, b) => (modOrder.indexOf(a.name) < 0 ? 99 : modOrder.indexOf(a.name)) - (modOrder.indexOf(b.name) < 0 ? 99 : modOrder.indexOf(b.name)) || b.qtd - a.qtd);
    const fornAll = group((r) => r.fornecedor).sort((a, b) => b.valor - a.valor);
    const byForn = fornAll.slice(0, 10);
    const byUf = group((r) => r.uf).sort((a, b) => b.valor - a.valor);
    const byMod = group((r) => r.modalidade).sort((a, b) => b.qtd - a.qtd);
    const byClasse = (["ok", "pending", "warn", "crit"] as Classe[]).map((c) => ({
      name: CLASSE_LABEL[c], c, qtd: filtered.filter((r) => r.classe === c).length,
      valor: filtered.filter((r) => r.classe === c).reduce((s, r) => s + r.valor, 0),
    }));
    return { byModGroup, byForn, fornAll, byUf, byMod, byClasse };
  }, [base]);

  const insights = useMemo(() => {
    const out: string[] = [];
    const filtered = base;
    if (!filtered.length) return out;
    const { byForn, byUf, byMod } = charts;
    if (byForn[0]) out.push(`${byForn[0].name} concentra ${((byForn[0].valor / kpi.total) * 100).toFixed(1)}% do valor em trânsito (${brl(byForn[0].valor)}).`);
    out.push(`${((kpi.critCount / kpi.count) * 100).toFixed(1)}% das notas estão críticas (30+ dias), somando ${brl(kpi.critValor)}.`);
    if (byUf[0]) out.push(`A filial ${byUf[0].name} lidera em valor com ${byUf[0].qtd} notas (${brl(byUf[0].valor)}).`);
    if (byMod[0]) out.push(`Modalidade predominante: ${byMod[0].name} — ${byMod[0].qtd} notas (${((byMod[0].qtd / kpi.count) * 100).toFixed(0)}%).`);
    const oldest = filtered.reduce((a, b) => (b.dias > a.dias ? b : a));
    out.push(`Nota mais antiga: ${oldest.nota} (${oldest.fornecedor}/${oldest.uf}) com ${oldest.dias} dias.`);
    if (kpi.semStatus) out.push(`${kpi.semStatus} notas ainda sem status operacional definido.`);
    return out;
  }, [base, charts, kpi]);

  const setF = (k: keyof Filters, v: string) => setFilters((f) => ({ ...f, [k]: v }));
  const toggleSort = (key: SortKey) => setSort((s) => ({ key, dir: s.key === key && s.dir === "desc" ? "asc" : "desc" }));

  const handleImport = async (file: File) => {
    if (!db) return;
    try {
      const XLSX = await import("xlsx");
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true, raw: false, dense: true });
      const ws = wb.Sheets[wb.SheetNames[0]!]!;
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: null, raw: true });
      const { state, summary } = reconcile(db, rows);
      if (commit(state)) { setSummary(summary); setSelected(new Set()); toast.success("Importação concluída"); }
    } catch (e) {
      toast.error(`Falha na importação: ${(e as Error).message}. A base não foi alterada.`);
    } finally { if (fileRef.current) fileRef.current.value = ""; }
  };

  const handleExport = async () => {
    try {
      if (!filtered.length) { toast.error("Nenhum registro para exportar."); return; }
      const XLSX = await import("xlsx");
      const seen = new Set<string>();
      const data = filtered.filter((r) => !seen.has(r.key) && seen.add(r.key)).map((r) => {
        const [y, m, d] = r.dataEmissao.split("-").map(Number) as [number, number, number];
        return {
          "Data Emissão": new Date(Date.UTC(y, m - 1, d, 12)), "Nº Nota": Number(r.nota) || r.nota, "UF Filial": r.uf, Fornecedor: r.fornecedor,
          Modalidade: r.modalidade, "Valor (R$)": r.valor, "Dias NF": r.dias, Classificação: CLASSE_LABEL[r.classe],
          "Previsão de Entrega": r.previsao ? (() => { const [py, pm, pd] = r.previsao.split("-").map(Number) as [number, number, number]; return new Date(Date.UTC(py, pm - 1, pd, 12)); })() : null,
          Transportadora: r.transportadora, Status: r.status, Observações: r.observacoes,
        };
      });
      const ws = XLSX.utils.json_to_sheet(data, { cellDates: true });
      const range = XLSX.utils.decode_range(ws["!ref"]!);
      for (let R = 1; R <= range.e.r; R++) {
        const a = ws[XLSX.utils.encode_cell({ r: R, c: 0 })]; if (a) a.z = "dd/mm/yyyy";
        const v = ws[XLSX.utils.encode_cell({ r: R, c: 5 })]; if (v) v.z = '"R$" #,##0.00';
        const pv = ws[XLSX.utils.encode_cell({ r: R, c: 8 })]; if (pv && pv.t !== "z") pv.z = "dd/mm/yyyy";
      }
      ws["!autofilter"] = { ref: ws["!ref"]! };
      ws["!cols"] = [12, 10, 9, 22, 14, 14, 8, 16, 14, 22, 30, 40].map((w) => ({ wch: w }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Detalhamento Fiscal");
      XLSX.writeFile(wb, `detalhamento-fiscal-${new Date().toISOString().slice(0, 10)}.xlsx`);
      toast.success(`${data.length} registros exportados para Excel.`);
    } catch (e) { toast.error(`Erro ao exportar: ${(e as Error).message}`); }
  };

  const doClear = () => {
    if (!db) return;
    if (commit(clearImported(db))) { toast.success("Relação de notas limpa. Transportadora, status, previsão e observações foram preservados — importe a nova base."); setSelected(new Set()); }
    setConfirmClear(false);
  };

  const doDelete = () => {
    if (!db) return;
    if (commit(softDelete(db, [...selected]))) { toast.success(`${selected.size} nota(s) removida(s) da listagem ativa. Histórico preservado.`); setSelected(new Set()); }
    setConfirmDel(false);
  };

  const updateOp = (key: string, field: "transportadora" | "status" | "observacoes" | "previsao", value: string) => { if (db) commit(setOp(db, key, field, value.trim())); };

  if (session === null) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Verificando acesso…</div>;
  if (!session) return <LoginScreen />;
  if (!db) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Carregando base…</div>;

  const PAGE = 50;
  const pageRows = filtered.slice(page * PAGE, page * PAGE + PAGE);
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const allPageSelected = pageRows.length > 0 && pageRows.every((r) => selected.has(r.key));
  const inactive = Object.values(db.notas).filter((n) => !n.active);
  const activeFilters = Object.values(filters).filter(Boolean).length;

  const SortTh = ({ k, children, right }: { k: SortKey; children: React.ReactNode; right?: boolean }) => (
    <th className={`px-3 py-3 font-semibold ${right ? "text-right" : "text-left"}`}>
      <button onClick={() => toggleSort(k)} className="inline-flex items-center gap-1 hover:text-foreground">
        {children}
        {sort.key === k ? (sort.dir === "asc" ? <ArrowUp className="h-3.5 w-3.5 text-primary" /> : <ArrowDown className="h-3.5 w-3.5 text-primary" />) : <ArrowUpDown className="h-3.5 w-3.5 opacity-40" />}
      </button>
    </th>
  );

  return (
    <div className="relative mx-auto max-w-[1500px] px-4 py-8 md:px-8">
      <Button size="sm" variant="outline" onClick={() => void supabase.auth.signOut()} className="absolute right-4 top-4 z-10 h-8 rounded-lg px-3 text-xs md:right-8"><LogOut className="h-3.5 w-3.5" /> Sair</Button>
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-5">
          <img src={logoAsset.url} alt="Rede Ancora" className="h-20 w-20 rounded-2xl object-cover shadow-lg md:h-24 md:w-24" />
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Rede Ancora · Controle Operacional</p>
            <h1 className="mt-1 text-4xl font-bold tracking-tight md:text-5xl">Painel de Notas em Trânsito</h1>
            <p className="mt-2 text-muted-foreground">{active.length.toLocaleString("pt-BR")} notas ativas · {inactive.length} arquivadas</p>
          </div>
        </div>
        <div className="flex gap-2">
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => e.target.files?.[0] && handleImport(e.target.files[0])} />
          <Button size="lg" onClick={() => fileRef.current?.click()} className="rounded-xl shadow-soft"><Upload /> Importar nova base</Button>
        </div>
      </header>

      <Tabs defaultValue="dash">
        <TabsList className="mb-6 h-12 rounded-xl p-1">
          <TabsTrigger value="dash" className="rounded-lg px-5">Visão Geral</TabsTrigger>
          <TabsTrigger value="det" className="rounded-lg px-5">Detalhamento Fiscal</TabsTrigger>
          <TabsTrigger value="hist" className="rounded-lg px-5">Histórico</TabsTrigger>
          <TabsTrigger value="cfg" className="rounded-lg px-5">Status</TabsTrigger>
        </TabsList>

        <TabsContent value="dash" className="space-y-6">
          <div className="filters flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3">
            <span className="text-sm font-semibold">Filtrar por CD</span>
            <select className="field rounded-lg border px-3 text-foreground" style={{ height: "2.5rem" }} value={cdSel} onChange={(e) => setCdSel(e.target.value)}>
              <option value="">Todos os CDs</option>
              {cdOptions.map((u) => <option key={u} value={u}>CD / UF {u}</option>)}
            </select>
            {cdSel && <Button size="sm" variant="ghost" onClick={() => setCdSel("")}>Limpar</Button>}
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Kpi big icon={<FileText />} label="Total de notas faturadas" value={kpi.count.toLocaleString("pt-BR")} sub={`${kpi.semStatus} sem status · média de ${kpi.avgDias.toFixed(1)} dias`} />
            <Kpi big icon={<Wallet />} label="Valor total das notas" value={brl(kpi.total)} sub={`${charts.byUf.length} CDs · ${charts.fornAll.length} fornecedores`} />
          </div>
          <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
            {charts.byClasse.map((c) => (
              <div key={c.c} className="panel border-l-4 p-5" style={{ borderLeftColor: CLASSE_COLOR[c.c] }}>
                <p className="text-sm font-medium" style={{ color: CLASSE_COLOR[c.c] }}>{c.name}</p>
                <p className="mt-2 font-display text-3xl font-bold">{c.qtd.toLocaleString("pt-BR")}</p>
                <p className="mt-1 text-sm text-muted-foreground">{brl(c.valor)}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <section className="panel p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-border pb-4">
                <h3 className="flex items-center gap-2 text-lg font-semibold"><Building2 className="h-5 w-5 text-primary" /> Destaque: Notas Emitidas por CD (UF Filial)</h3>
                <span className="text-sm text-muted-foreground">Qtd NFs e Valor Total Faturado</span>
              </div>
              <div className="grid max-h-[420px] gap-3 overflow-y-auto pr-2 sm:grid-cols-2">
                {charts.byUf.map((r) => (
                  <div key={r.name} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-4">
                    <div>
                      <p className="font-semibold text-primary">CD / UF {r.name}</p>
                      <p className="text-sm text-muted-foreground">{r.qtd.toLocaleString("pt-BR")} NFs Faturadas</p>
                    </div>
                    <p className="whitespace-nowrap font-bold tabular-nums">{brl(r.valor)}</p>
                  </div>
                ))}
                {!charts.byUf.length && <p className="text-sm text-muted-foreground">Sem notas importadas.</p>}
              </div>
            </section>
            <RankCard title="Destaque: Faturamento por Fornecedor" sub="Ranking Principais Fornecedores" icon={<Factory className="h-5 w-5 text-primary" />} rows={charts.fornAll} />
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <ChartCard title="Modalidades faturadas (Cross × Normal)">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={charts.byModGroup} dataKey="qtd" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={3} stroke="none">
                    {charts.byModGroup.map((m, i) => <Cell key={m.name} fill={MOD_COLOR[m.name] ?? CHARTS[i % 5]} />)}
                  </Pie>
                  <Tooltip content={<Tip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-2 text-sm">
                {charts.byModGroup.map((m, i) => (
                  <div key={m.name} className="flex items-center gap-2 rounded-lg px-2 py-1">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: MOD_COLOR[m.name] ?? CHARTS[i % 5] }} />
                    <span className="text-muted-foreground">{m.name}</span><span className="ml-auto font-semibold">{m.qtd}</span>
                  </div>
                ))}
              </div>
            </ChartCard>
            <ChartCard title="Classificação por prazo">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={charts.byClasse} dataKey="qtd" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={3} stroke="none">
                    {charts.byClasse.map((c) => <Cell key={c.c} fill={CLASSE_COLOR[c.c]} />)}
                  </Pie>
                  <Tooltip content={<Tip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-2 text-sm">
                {charts.byClasse.map((c) => (
                  <div key={c.c} className="flex items-center gap-2 rounded-lg px-2 py-1">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: CLASSE_COLOR[c.c] }} />
                    <span className="text-muted-foreground">{c.name}</span><span className="ml-auto font-semibold">{c.qtd}</span>
                  </div>
                ))}
              </div>
            </ChartCard>
          </div>

          <div className="grid gap-6">
            <ChartCard title="Top 10 fornecedores (valor)">
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={charts.byForn} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid stroke="var(--border)" horizontal={false} />
                  <XAxis type="number" stroke="var(--muted-foreground)" fontSize={12} tickFormatter={brlShort} tickLine={false} axisLine={false} />
                  <YAxis type="category" dataKey="name" stroke="var(--muted-foreground)" fontSize={12} width={120} tickLine={false} axisLine={false} />
                  <Tooltip content={<Tip money />} cursor={{ fill: "var(--accent)" }} />
                  <Bar dataKey="valor" radius={[0, 8, 8, 0]} fill="var(--chart-2)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <div className="grid gap-6 xl:grid-cols-3">
            <ChartCard title="Valor por UF filial" className="xl:col-span-2">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={charts.byUf}>
                  <CartesianGrid stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} tickFormatter={brlShort} tickLine={false} axisLine={false} width={70} />
                  <Tooltip content={<Tip money />} cursor={{ fill: "var(--accent)" }} />
                  <Bar dataKey="valor" radius={[8, 8, 0, 0]} fill="var(--chart-1)" />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
            <section className="panel p-5">
              <h3 className="mb-4 flex items-center gap-2 text-lg font-semibold"><Lightbulb className="h-5 w-5 text-primary" /> Insights automáticos</h3>
              <ul className="space-y-3">
                {insights.length ? insights.map((t, i) => <li key={i} className="rounded-xl bg-secondary p-3 text-sm leading-relaxed">{t}</li>) : <li className="text-sm text-muted-foreground">Sem dados para os filtros atuais.</li>}
              </ul>
            </section>
          </div>
        </TabsContent>

        <TabsContent value="det">
      {/* Filtros */}
      <section className="filters panel mb-6 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Filtros de Pesquisa Avançados {activeFilters > 0 && <span className="ml-2 rounded-full bg-primary/15 px-2 py-0.5 text-sm text-primary">{activeFilters} ativo(s)</span>}</h2>
          <Button variant="ghost" onClick={() => setFilters(NO_FILTERS)}><X /> Limpar Filtros</Button>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-4">
          <L t="Emissão de"><input type="date" className="field" value={filters.de} onChange={(e) => setF("de", e.target.value)} /></L>
          <L t="Emissão até"><input type="date" className="field" value={filters.ate} onChange={(e) => setF("ate", e.target.value)} /></L>
          <L t="Nº Nota"><input className="field" placeholder="Buscar…" value={filters.nota} onChange={(e) => setF("nota", e.target.value)} /></L>
          <L t="UF Filial"><Sel v={filters.uf} on={(v) => setF("uf", v)} opts={options.uf} /></L>
          <L t="Fornecedor"><Sel v={filters.fornecedor} on={(v) => setF("fornecedor", v)} opts={options.fornecedor} /></L>
          <L t="Modalidade"><Sel v={filters.modalidade} on={(v) => setF("modalidade", v)} opts={options.modalidade} /></L>
          <L t="Classificação">
            <select className="field" value={filters.classe} onChange={(e) => setF("classe", e.target.value)}>
              <option value="">Todas</option>{(Object.keys(CLASSE_LABEL) as Classe[]).map((c) => <option key={c} value={c}>{CLASSE_LABEL[c]}</option>)}
            </select>
          </L>
          <L t="Status">
            <select className="field" value={filters.status} onChange={(e) => setF("status", e.target.value)}>
              <option value="">Todos</option><option value="__none">Sem status</option>{db.statusOptions.map((s) => <option key={s}>{s}</option>)}
            </select>
          </L>
        </div>
      </section>

          <section className="panel overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-4">
              <p className="text-sm text-muted-foreground"><b className="text-foreground">{filtered.length.toLocaleString("pt-BR")}</b> registros · Total <b className="text-foreground">{brl(filteredTotal)}</b>{selected.size > 0 && <> · <b className="text-primary">{selected.size} selecionada(s)</b></>}</p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setConfirmClear(true)}><Eraser /> Limpar dados</Button>
                <Button variant="destructive" disabled={!selected.size} onClick={() => setConfirmDel(true)}><Trash2 /> Excluir Nota Fiscal</Button>
                <Button variant="secondary" onClick={handleExport}><Download /> Exportar para Excel</Button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="notes-table w-full text-[0.95rem]">
                <thead className="bg-secondary text-[0.8rem] uppercase tracking-wide text-secondary-foreground/90">
                  <tr>
                    <th className="w-10 px-3 py-3"><Checkbox checked={allPageSelected} onCheckedChange={(c) => setSelected((s) => { const n = new Set(s); pageRows.forEach((r) => (c ? n.add(r.key) : n.delete(r.key))); return n; })} /></th>
                    <SortTh k="dataEmissao">Data Emissão</SortTh>
                    <SortTh k="nota">Nº Nota</SortTh>
                    <SortTh k="uf">UF</SortTh>
                    <SortTh k="fornecedor">Fornecedor</SortTh>
                    <th className="px-3 py-3 text-left font-semibold">Modalidade</th>
                    <SortTh k="valor" right>Valor (R$)</SortTh>
                    <SortTh k="dias" right>Dias NF</SortTh>
                    <th className="min-w-40 px-3 py-3 text-left font-semibold">Previsão de entrega</th>
                    <th className="px-3 py-3 text-left font-semibold">Classificação</th>
                    <th className="min-w-44 px-3 py-3 text-left font-semibold">Transportadora</th>
                    <th className="min-w-56 px-3 py-3 text-left font-semibold">Status</th>
                    <th className="min-w-72 px-3 py-3 text-left font-semibold">Observações</th>
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map((r) => (
                    <tr key={r.key} className={`hover:bg-accent/40 ${selected.has(r.key) ? "bg-primary/5" : ""}`}>
                      <td className="px-3 py-2"><Checkbox checked={selected.has(r.key)} onCheckedChange={() => setSelected((s) => { const n = new Set(s); n.has(r.key) ? n.delete(r.key) : n.add(r.key); return n; })} /></td>
                      <td className="px-3 py-2 tabular-nums">{fmtDate(r.dataEmissao)}</td>
                      <td className="px-3 py-2 font-semibold tabular-nums">{r.nota}</td>
                      <td className="px-3 py-2">{r.uf}</td>
                      <td className="px-3 py-2">{r.fornecedor}</td>
                      <td className="px-3 py-2 text-foreground/90">{r.modalidade}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{brl(r.valor)}</td>
                      <td className="px-3 py-2 text-right font-semibold tabular-nums" style={{ color: CLASSE_COLOR[r.classe] }}>{r.dias}</td>
                      <td className="px-2 py-1"><input type="date" className="cell-input" value={r.previsao} onChange={(e) => updateOp(r.key, "previsao", e.target.value)} /></td>
                      <td className="px-3 py-2"><span className={`inline-flex whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-semibold ${CLASSE_BADGE[r.classe]}`}>{CLASSE_LABEL[r.classe]}</span></td>
                      <td className="px-2 py-1"><DraftField value={r.transportadora} placeholder="Informar…" onSave={(v) => updateOp(r.key, "transportadora", v)} /></td>
                      <td className="px-2 py-1">
                        <select className="cell-input" value={r.status} onChange={(e) => updateOp(r.key, "status", e.target.value)}>
                          <option value="">—</option>
                          {[...new Set([...db.statusOptions, ...(r.status ? [r.status] : [])])].map((s) => <option key={s}>{s}</option>)}
                        </select>
                      </td>
                      <td className="px-2 py-1"><DraftField multiline value={r.observacoes} placeholder="Anotações importantes…" onSave={(v) => updateOp(r.key, "observacoes", v)} /></td>
                    </tr>
                  ))}
                  {!pageRows.length && <tr><td colSpan={13} className="p-10 text-center text-muted-foreground">Nenhuma nota encontrada para os filtros atuais.</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-border p-4 text-sm text-muted-foreground">
              <span>Página {page + 1} de {pages}</span>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Anterior</Button>
                <Button variant="secondary" size="sm" disabled={page >= pages - 1} onClick={() => setPage((p) => p + 1)}>Próxima</Button>
              </div>
            </div>
          </section>
        </TabsContent>

        <TabsContent value="hist" className="grid gap-6 xl:grid-cols-2">
          <section className="panel p-5">
            <h3 className="mb-1 flex items-center gap-2 text-lg font-semibold"><Archive className="h-5 w-5 text-primary" /> Notas fora da listagem ativa</h3>
            <p className="mb-4 text-sm text-muted-foreground">Excluídas pelo usuário ou ausentes na última base. Transportadora e Status ficam preservados.</p>
            <div className="max-h-[520px] space-y-2 overflow-y-auto pr-1">
              {inactive.length ? inactive.map((n) => (
                <div key={n.key} className="flex items-center gap-3 rounded-xl bg-secondary p-3 text-sm">
                  <div className="flex-1">
                    <p className="font-semibold">NF {n.nota} · {n.fornecedor} · {n.uf}</p>
                    <p className="text-muted-foreground">{brl(n.valor)} · {n.deleted ? "Excluída" : "Ausente na base"}{db.ops[n.key]?.status ? ` · ${db.ops[n.key]!.status}` : ""}{db.ops[n.key]?.transportadora ? ` · ${db.ops[n.key]!.transportadora}` : ""}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => { commit(restore(db, [n.key])); toast.success(`NF ${n.nota} restaurada`); }}><RotateCcw /> Restaurar</Button>
                </div>
              )) : <p className="text-sm text-muted-foreground">Nenhuma nota arquivada.</p>}
            </div>
          </section>
          <section className="panel p-5">
            <h3 className="mb-4 text-lg font-semibold">Registro de auditoria</h3>
            <div className="max-h-[560px] space-y-2 overflow-y-auto pr-1">
              {db.audit.map((a, i) => (
                <div key={i} className="rounded-xl bg-secondary p-3 text-sm">
                  <p className="font-semibold">{a.action} <span className="font-normal text-muted-foreground">· {new Date(a.at).toLocaleString("pt-BR")}</span></p>
                  <p className="text-muted-foreground">{a.detail}</p>
                </div>
              ))}
            </div>
          </section>
        </TabsContent>

        <TabsContent value="cfg">
          <section className="panel max-w-2xl p-5">
            <h3 className="mb-1 flex items-center gap-2 text-lg font-semibold"><Truck className="h-5 w-5 text-primary" /> Opções de status</h3>
            <p className="mb-4 text-sm text-muted-foreground">Adicione novas situações operacionais sem alterar o sistema.</p>
            <form className="mb-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); const v = newStatus.trim(); if (!v || db.statusOptions.includes(v)) return; commit({ ...db, statusOptions: [...db.statusOptions, v] }); setNewStatus(""); }}>
              <input className="field" placeholder="Nova situação…" value={newStatus} onChange={(e) => setNewStatus(e.target.value)} />
              <Button type="submit"><Plus /> Adicionar</Button>
            </form>
            <div className="space-y-2">
              {db.statusOptions.map((s) => (
                <div key={s} className="flex items-center justify-between rounded-xl bg-secondary px-3 py-2 text-sm">
                  <span>{s}</span>
                  <Button size="sm" variant="ghost" onClick={() => commit({ ...db, statusOptions: db.statusOptions.filter((x) => x !== s) })}><X /></Button>
                </div>
              ))}
            </div>
          </section>
        </TabsContent>
      </Tabs>

      <AlertDialog open={confirmDel} onOpenChange={setConfirmDel}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir {selected.size} nota(s) fiscal(is)?</AlertDialogTitle>
            <AlertDialogDescription>As notas sairão da listagem ativa. Transportadora, Status e histórico serão preservados e podem ser restaurados na aba Histórico.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete}>Confirmar exclusão</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={confirmClear} onOpenChange={setConfirmClear}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Limpar a relação atual de notas?</AlertDialogTitle>
            <AlertDialogDescription>Todas as notas importadas serão removidas para você importar uma nova base. Previsão de entrega, transportadora, status e observações ficam guardados e voltam automaticamente quando a nota for reimportada.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={doClear}>Limpar dados</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!summary} onOpenChange={(o) => !o && setSummary(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Resumo da importação</AlertDialogTitle>
            <AlertDialogDescription>{summary?.lidos} linhas lidas na planilha.</AlertDialogDescription>
          </AlertDialogHeader>
          {summary && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-sm">
                {([["Incluídas", summary.incluidos], ["Atualizadas", summary.atualizados], ["Inalteradas", summary.inalterados], ["Reativadas", summary.reativados], ["Ignoradas", summary.ignorados], ["Rejeitadas", summary.rejeitados], ["Arquivadas (ausentes)", summary.ausentes]] as const).map(([l, v]) => (
                  <div key={l} className="flex justify-between rounded-lg bg-secondary px-3 py-2"><span className="text-muted-foreground">{l}</span><b>{v}</b></div>
                ))}
              </div>
              {summary.erros.length > 0 && (
                <div className="max-h-40 overflow-y-auto rounded-lg border border-crit/30 bg-crit/10 p-3 text-xs">
                  <p className="mb-1 flex items-center gap-1 font-semibold text-crit"><AlertTriangle className="h-3.5 w-3.5" /> Inconsistências</p>
                  {summary.erros.slice(0, 100).map((e, i) => <p key={i}>{e}</p>)}
                </div>
              )}
            </div>
          )}
          <AlertDialogFooter><AlertDialogAction>OK</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function L({ t, children }: { t: string; children: React.ReactNode }) {
  return <label className="block"><span className="mb-1 block text-[0.85rem] font-medium text-foreground/80">{t}</span>{children}</label>;
}
function Sel({ v, on, opts }: { v: string; on: (v: string) => void; opts: string[] }) {
  return <select className="field" value={v} onChange={(e) => on(e.target.value)}><option value="">Todos</option>{opts.map((o) => <option key={o}>{o}</option>)}</select>;
}
function RankCard({ title, sub, icon, rows }: { title: string; sub: string; icon: React.ReactNode; rows: { name: string; valor: number; qtd: number }[] }) {
  return (
    <section className="panel p-5">
      <div className="mb-4 flex items-center justify-between gap-3 border-b border-border pb-4">
        <h3 className="flex min-w-0 items-center gap-2 truncate text-base font-semibold">{icon} <span className="truncate">{title}</span></h3>
        <span className="shrink-0 whitespace-nowrap text-xs text-muted-foreground">{sub}</span>
      </div>
      <div className="max-h-[420px] space-y-3 overflow-y-auto pr-2">
        {rows.map((r, i) => (
          <div key={r.name} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-background/60 px-4 py-4">
            <div className="flex min-w-0 items-center gap-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-accent text-sm font-bold text-primary">{i + 1}</span>
              <div className="min-w-0">
                <p className="truncate font-semibold">{r.name}</p>
                <p className="text-sm text-muted-foreground">{r.qtd.toLocaleString("pt-BR")} NFs emitidas</p>
              </div>
            </div>
            <p className="whitespace-nowrap font-bold tabular-nums text-ok">{brl(r.valor)}</p>
          </div>
        ))}
        {!rows.length && <p className="text-sm text-muted-foreground">Sem notas importadas.</p>}
      </div>
    </section>
  );
}
function Kpi({ icon, label, value, sub, tone, big }: { icon: React.ReactNode; label: string; value: string; sub: string; tone?: "crit"; big?: boolean }) {
  return (
    <div className="panel p-5">
      <div className="flex items-center justify-between text-muted-foreground"><span className="text-sm font-medium">{label}</span><span className={`[&>svg]:h-5 [&>svg]:w-5 ${tone ? "text-crit" : "text-primary"}`}>{icon}</span></div>
      <p className={`mt-3 font-display ${big ? "text-5xl" : "text-4xl"} font-bold tracking-tight ${tone ? "text-crit" : ""}`}>{value}</p>
      <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
    </div>
  );
}
function ChartCard({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) {
  return <section className={`panel p-5 ${className}`}><h3 className="mb-4 text-lg font-semibold">{title}</h3>{children}</section>;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function Tip({ active, payload, money }: any) {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-xl border border-border bg-popover px-3 py-2 text-sm shadow-soft">
      <p className="font-semibold">{p.name ? (/^\d{4}-/.test(p.name) ? fmtDate(p.name) : p.name) : ""}</p>
      {money ? <p className="text-muted-foreground">{brl(p.valor)} · {p.qtd} notas</p> : <p className="text-muted-foreground">{p.qtd} notas</p>}
    </div>
  );
}

/** Campo editável que mantém o rascunho enquanto a pessoa digita,
 *  mesmo que outros usuários atualizem o painel ao mesmo tempo. */
function DraftField({ value, onSave, placeholder, multiline }: { value: string; onSave: (v: string) => void; placeholder: string; multiline?: boolean }) {
  const [draft, setDraft] = useState(value);
  const [editing, setEditing] = useState(false);
  useEffect(() => { if (!editing) setDraft(value); }, [value, editing]);
  const finish = () => { setEditing(false); if (draft !== value) onSave(draft); };
  const common = { value: draft, placeholder, onFocus: () => setEditing(true), onBlur: finish };
  return multiline
    ? <textarea rows={1} className="cell-input min-h-9 resize-y" {...common} onChange={(e) => setDraft(e.target.value)} />
    : <input className="cell-input" {...common} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()} />;
}
