# Roadmap

- [x] Faturamento por fornecedor no modelo enviado (ranking com numeração)
- [x] Remover o gráfico "Valor por data de emissão"
- [x] Criar gráfico de modalidades faturadas (Cross × Normal) no formato de "Classificação por prazo"
- [x] Migrar dados do localStorage para o banco na nuvem (tabelas nf_notas, nf_ops, nf_audit, nf_status_options)
- [x] Ativar login por e-mail/senha e criar tela de acesso (convidados, sem perfil)
- [x] Sincronização em tempo real entre todos os acessos (Realtime)
- [x] Semear base inicial a partir de public/data/notas.json no primeiro acesso
- [ ] Pendente (ação do usuário): criar o primeiro usuário convidado em Backend → Users para validar o acesso de ponta a ponta
- [ ] Pendente (ação do usuário): liberar cada novo acesso cadastrando o convidado em Backend → Users (sem cadastro aberto)
